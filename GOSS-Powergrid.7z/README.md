GOSS-Powergrid
==============

A powergrid project cabable of dealing with node/breaker and bus/branch constructs.


Installation Windows 7

Clone the goss repository (git clone https://github.com/GridOPTICS/GOSS-Powergrid.git)
Open command line to the repository root (i.e. git/GOSS folder)
Execute gradlew install 
Installation Linux

Open terminal
Clone repository (git clone https://github.com/GridOPTICS/GOSS-Powergrid.git)
Change directory to goss (cd GOSS)
Add execute to gradlew (chmod +x gradlew)
Build core project (./gradlew install )
