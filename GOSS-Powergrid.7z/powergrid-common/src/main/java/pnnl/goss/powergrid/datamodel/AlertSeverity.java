package pnnl.goss.powergrid.datamodel;

public enum AlertSeverity {
	SEVERITY_HIGH,
	SEVERITY_WARN
	
}
