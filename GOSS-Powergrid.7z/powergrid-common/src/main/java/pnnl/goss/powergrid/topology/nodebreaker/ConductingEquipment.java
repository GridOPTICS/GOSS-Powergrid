package pnnl.goss.powergrid.topology.nodebreaker;

public interface ConductingEquipment {

}
