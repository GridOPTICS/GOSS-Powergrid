package pnnl.goss.powergrid.topology.nodebreaker;

public interface EquipmentContainer {

}
