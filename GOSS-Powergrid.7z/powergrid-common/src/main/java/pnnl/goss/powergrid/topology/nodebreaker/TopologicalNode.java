package pnnl.goss.powergrid.topology.nodebreaker;
import static pnnl.goss.powergrid.topology.NodeBreakerDataType.*;
public class TopologicalNode {
	
//	private String mrid;
//	
//	private HashMap<String, ConnectivityNode> connectivityNodes = new HashMap<String, ConnectivityNode>();
//	
//	
//	public String getMrid() {
//		return mrid;
//	}
//
//	public void setMrid(String mrid) {
//		this.mrid = mrid;
//	}
//
//	public void addConnectivityNode(ConnectivityNode node){
//		node.setTopologicalNode(this);
//		connectivityNodes.put(node.getMrid(), node);
//	}
	

}
