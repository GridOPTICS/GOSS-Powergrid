package pnnl.goss.powergrid.topology.nodebreaker;

public interface PowerSystemResource {

}
