package pnnl.goss.powergrid.datamodel;

public enum AlertType {
	ALERTTYPE_SUBSTATION,
	ALERTTYPE_BRANCH
}
