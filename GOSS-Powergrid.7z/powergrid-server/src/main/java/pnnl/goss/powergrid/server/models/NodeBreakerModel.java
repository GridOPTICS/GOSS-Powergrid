package pnnl.goss.powergrid.server.models;

public class NodeBreakerModel {
	
}
