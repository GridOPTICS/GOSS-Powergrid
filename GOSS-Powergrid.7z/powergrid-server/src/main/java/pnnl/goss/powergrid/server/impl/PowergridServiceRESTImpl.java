//package pnnl.goss.powergrid.server.impl;
//
//import pnnl.goss.powergrid.server.PowergridServiceREST;
//
//public class PowergridServiceRESTImpl implements PowergridServiceREST {
//
//}
