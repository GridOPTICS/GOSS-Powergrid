
public class Stub {

}
